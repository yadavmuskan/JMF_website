import React from 'react'
// import Footer from '../components/Footer'
import HeroImage from '../components/HeroImage'
// import Navbar from '../components/Navbar'
// import Form from '../components/Form'
import Heroimage2 from '../components/Heroimage2';

const Contact = () => {
    return (
        <div>
            {/* <Navbar /> */}
            <HeroImage />
            {/* <Form /> */}
            <Heroimage2/>
            {/* <Footer/> */}
        </div>
    ) 
}

export default Contact
