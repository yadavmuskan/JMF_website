import React from 'react'
import './Bands.css';

export default function Bands() {
  return (
    <div>

<h1>Flickity - autoPlay</h1>


<div class="carousel" data-flickity='{ "autoPlay": true }'>
  <div class="carousel-cell"></div>
  <div class="carousel-cell"></div>
  <div class="carousel-cell"></div>
  <div class="carousel-cell"></div>
  <div class="carousel-cell"></div>
</div>

    </div>
  )
}
